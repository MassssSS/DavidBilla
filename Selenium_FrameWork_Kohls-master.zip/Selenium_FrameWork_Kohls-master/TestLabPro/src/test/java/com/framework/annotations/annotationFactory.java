package com.framework.annotations;

public class annotationFactory {
	public  @interface Author {
		String value();
	}
	public @interface TC_NO {
		String value();
	}
}
